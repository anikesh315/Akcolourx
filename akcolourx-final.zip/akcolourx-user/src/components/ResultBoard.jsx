// ResultBoard component
