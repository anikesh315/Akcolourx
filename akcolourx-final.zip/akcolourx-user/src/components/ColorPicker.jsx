// ColorPicker component
