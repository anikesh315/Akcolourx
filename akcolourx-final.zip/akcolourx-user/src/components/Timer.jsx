// Timer component
