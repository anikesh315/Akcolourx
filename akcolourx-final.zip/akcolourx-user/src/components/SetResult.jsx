// Admin set result
