// Home page component for user
