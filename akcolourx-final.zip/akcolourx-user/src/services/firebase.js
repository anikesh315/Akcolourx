// Firebase config for Akcolourx

const firebaseConfig = {
  apiKey: "AIzaSyBe0DFtj7BtQk7COzLI95xzSnwRrsNmEFg",
  authDomain: "akcolourx.firebaseapp.com",
  projectId: "akcolourx",
  storageBucket: "akcolourx.appspot.com",
  messagingSenderId: "662788096317",
  appId: "1:662788096317:web:placeholderAppId" // Replace this if you get the real appId
};
